import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MatBadgeModule } from '@angular/material/badge';
import { ThirdComponent } from './third/third.component';
import {MatIconModule} from '@angular/material/icon';
import {MatChipsModule} from '@angular/material/chips';
import {MatInputModule} from '@angular/material/input';
import {MatListModule} from '@angular/material/list';
import {MatMenuModule} from '@angular/material/menu';
import { FourthComponent } from './fourth/fourth.component';
import { FormsModule } from '@angular/forms';

const MatBadgeComponents =[
  MatBadgeModule
]
@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    ThirdComponent,
    FourthComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatBadgeComponents,
    MatIconModule,
    MatChipsModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'first', component: FirstComponent},
      {path: 'second', component: SecondComponent},
      {path: 'third', component: ThirdComponent},
      {path: 'fourth', component: FourthComponent}

    ])
  ],
  exports : [MatBadgeComponents],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
