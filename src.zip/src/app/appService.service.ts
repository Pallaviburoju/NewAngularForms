import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { FourthComponent } from './fourth/fourth.component';

@Injectable({
  providedIn: 'root'
})

export class AppServiceService {
  url = 'http://localhost:8909/get'
   constructor(private httpService : HttpClient, private Fou: FourthComponent){ }

   public getData(): Observable<any>{
      return this.httpService.get(this.url);
   }
  
   public sendData(){
    return this.httpService.post(this.url ,  this.Fou.sendToService);
   }
}
