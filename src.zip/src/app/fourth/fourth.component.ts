import { Component, OnInit } from '@angular/core';
import { PersonalInfo } from '../personalInfo';

@Component({
  selector: 'app-fourth',
  templateUrl: './fourth.component.html',
  styleUrls: ['./fourth.component.css']
})
export class FourthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  personalInformation:PersonalInfo={
    customerName: '',
    customerEmail: '',
    customerPassword: '',
    customerPhoneNumber:'',
    customerAddress:'',
    customerCity: '',
    customerCountry: '',
    customerZip: ''

  };


 // personalInforamtion = new PersonalInfo('','','','','','','','');
  submitted = false;

  onSubmit(){
    this.submitted = true;
    alert(this.personalInformation.customerPassword);
    console.log(this.personalInformation)
  }

   getCurrentModel() { 
    return JSON.stringify(this.personalInformation); 
  }

  sendToService(){
    return this.personalInformation;
  }
}

// export interface PersonalInfo{

//   customerName: string ;
//   customerEmail: string ;
//   customerPassword: string ;
//   customerPhoneNumber: string ;
//   customerAddress: string ;
//   customerCity: string ;
//   customerZip: string ;
//   customerCountry: string ;
// }
