import { Component, OnInit } from '@angular/core';

import { HttpErrorResponse } from '@angular/common/http';
import { AppServiceService } from '../appService.service';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {

  empData : string[];
  company : string;
  constructor(private empService : AppServiceService) { }

  ngOnInit() {
    this.empService.getData().subscribe(data => {
      this.empData = data as string[];
      console.log(this.empData)
    },
    (err: HttpErrorResponse) => {
      console.log (err.message);
    })
  }
 
  count : number=0;
  title : string;
  onclick(){
    this.count = this.count+1;
    console.log(this.count)
  }

  data(){
    this.title = "hello"
  }

  numberA: number = 10;  
  numberB: number = 20;  
  
  addTwoNumbers() {  
    return this.numberA + this.numberB;  
  } 



}
